# MediTrack – Medicine Expiry Reminder System

A front-end mini project built using HTML, CSS and JavaScript.

## Features
- Add medicines with category, quantity, expiry date and notes
- Dashboard counts for all, expiring soon, expired and safe medicines
- Expiry status calculated automatically
- Search and filter medicines
- Edit and delete records
- Saves records in browser localStorage
- Responsive layout for desktop and mobile

## How to run
1. Extract `MediTrack_Mini_Project.zip`.
2. Open the extracted folder.
3. Double-click `index.html` to open it in a modern browser.
4. Add a medicine using the form. Your data remains in the same browser/device.

No server or package installation is required.

## Project structure
- `index.html` – page structure
- `css/style.css` – styling and responsive layout
- `js/app.js` – medicine management and expiry calculations

## Note
This is a student demo, not a medical advice tool. It does not send real push/email notifications. Always check medicine packaging and consult a pharmacist or healthcare professional about expired medicines.
