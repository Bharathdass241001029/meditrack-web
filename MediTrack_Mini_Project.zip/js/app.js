const STORAGE_KEY = "meditrack_medicines_v1";
const form = document.getElementById("medicineForm");
const nameInput = document.getElementById("medicineName");
const categoryInput = document.getElementById("category");
const quantityInput = document.getElementById("quantity");
const expiryInput = document.getElementById("expiryDate");
const notesInput = document.getElementById("notes");
const listEl = document.getElementById("medicineList");
const emptyEl = document.getElementById("emptyState");
const searchInput = document.getElementById("searchInput");
const filterSelect = document.getElementById("filterSelect");
const toastEl = document.getElementById("toast");
let medicines = loadMedicines();
let toastTimer;

function loadMedicines() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}
function saveMedicines() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(medicines));
}
function localDateOnly(date = new Date()) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}
function daysUntil(dateString) {
  const [year, month, day] = dateString.split("-").map(Number);
  const target = new Date(year, month - 1, day);
  return Math.round((target - localDateOnly()) / 86400000);
}
function statusFor(medicine) {
  const days = daysUntil(medicine.expiryDate);
  if (days < 0) return { key: "expired", label: "Expired", days };
  if (days <= 30) return { key: "soon", label: days === 0 ? "Expires today" : `Expires in ${days}d`, days };
  return { key: "safe", label: "Safe", days };
}
function formatDate(dateString) {
  const [year, month, day] = dateString.split("-").map(Number);
  return new Date(year, month - 1, day).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}
function showToast(message) {
  toastEl.textContent = message;
  toastEl.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove("show"), 2600);
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);
}
function iconFor(category) {
  return ({ Tablet: "💊", Capsule: "🟠", Syrup: "🧴", Ointment: "🩹", Drops: "💧", Other: "✚" })[category] || "💊";
}
function render() {
  const query = searchInput.value.trim().toLowerCase();
  const filter = filterSelect.value;
  const sorted = [...medicines].sort((a, b) => a.expiryDate.localeCompare(b.expiryDate));
  const filtered = sorted.filter(m => {
    const status = statusFor(m);
    const matchesText = `${m.name} ${m.category} ${m.notes || ""}`.toLowerCase().includes(query);
    return matchesText && (filter === "all" || status.key === filter);
  });

  const counts = medicines.reduce((acc, m) => {
    acc.total++;
    acc[statusFor(m).key]++;
    return acc;
  }, { total: 0, soon: 0, expired: 0, safe: 0 });
  document.getElementById("totalCount").textContent = counts.total;
  document.getElementById("soonCount").textContent = counts.soon;
  document.getElementById("expiredCount").textContent = counts.expired;
  document.getElementById("safeCount").textContent = counts.safe;
  document.getElementById("medicineLabel").textContent = `${filtered.length} ${filtered.length === 1 ? "item" : "items"}`;

  const urgent = medicines.filter(m => ["soon", "expired"].includes(statusFor(m).key));
  const banner = document.getElementById("alertBanner");
  if (urgent.length) {
    banner.hidden = false;
    const expired = urgent.filter(m => statusFor(m).key === "expired").length;
    const soon = urgent.length - expired;
    banner.textContent = `${expired ? `${expired} expired medicine${expired === 1 ? "" : "s"}` : ""}${expired && soon ? " · " : ""}${soon ? `${soon} medicine${soon === 1 ? "" : "s"} expiring within 30 days` : ""}. Review these items and consult a pharmacist before use or disposal.`;
  } else {
    banner.hidden = true;
  }

  listEl.innerHTML = filtered.map(m => {
    const status = statusFor(m);
    const daysText = status.days < 0 ? `${Math.abs(status.days)} day${Math.abs(status.days) === 1 ? "" : "s"} ago` : status.days === 0 ? "Today" : `In ${status.days} day${status.days === 1 ? "" : "s"}`;
    return `<article class="medicine-item">
      <div class="med-icon">${iconFor(m.category)}</div>
      <div class="med-main">
        <div class="med-title">${escapeHTML(m.name)}</div>
        <div class="med-meta">${escapeHTML(m.category)} · Qty ${escapeHTML(m.quantity)} · Expires ${formatDate(m.expiryDate)}</div>
        ${m.notes ? `<div class="med-notes">${escapeHTML(m.notes)}</div>` : ""}
      </div>
      <div class="med-right">
        <span class="status ${status.key}">${status.label}</span>
        <span class="expiry-text">${daysText}</span>
        <div class="item-actions">
          <button class="icon-btn" title="Edit medicine" aria-label="Edit ${escapeHTML(m.name)}" data-action="edit" data-id="${m.id}">✎</button>
          <button class="icon-btn delete" title="Delete medicine" aria-label="Delete ${escapeHTML(m.name)}" data-action="delete" data-id="${m.id}">×</button>
        </div>
      </div>
    </article>`;
  }).join("");
  emptyEl.hidden = filtered.length > 0;
  if (filtered.length === 0 && medicines.length > 0) {
    emptyEl.querySelector("h3").textContent = "No matching medicines";
    emptyEl.querySelector("p").textContent = "Try a different search term or status filter.";
    emptyEl.querySelector("a").hidden = true;
  } else {
    emptyEl.querySelector("h3").textContent = "Your medicine list is empty";
    emptyEl.querySelector("p").textContent = "Add your first medicine to start tracking expiry dates.";
    emptyEl.querySelector("a").hidden = false;
  }
}
form.addEventListener("submit", event => {
  event.preventDefault();
  const name = nameInput.value.trim();
  const expiryDate = expiryInput.value;
  if (!name || !expiryDate || Number(quantityInput.value) < 1) {
    showToast("Please complete the required fields.");
    return;
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(expiryDate)) {
    showToast("Please enter a valid expiry date.");
    return;
  }
  const editId = form.dataset.editId;
  const record = {
    id: editId || (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())),
    name, category: categoryInput.value, quantity: Number(quantityInput.value),
    expiryDate, notes: notesInput.value.trim()
  };
  if (editId) {
    medicines = medicines.map(m => m.id === editId ? record : m);
    delete form.dataset.editId;
    form.querySelector('button[type="submit"]').innerHTML = 'Save medicine <span>→</span>';
    showToast("Medicine updated successfully.");
  } else {
    medicines.push(record);
    showToast("Medicine added successfully.");
  }
  saveMedicines();
  form.reset();
  quantityInput.value = 1;
  render();
});
listEl.addEventListener("click", event => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const medicine = medicines.find(m => m.id === button.dataset.id);
  if (!medicine) return;
  if (button.dataset.action === "delete") {
    if (!confirm(`Delete ${medicine.name} from your list?`)) return;
    medicines = medicines.filter(m => m.id !== medicine.id);
    if (form.dataset.editId === medicine.id) {
      delete form.dataset.editId;
      form.reset();
      quantityInput.value = 1;
      form.querySelector('button[type="submit"]').innerHTML = 'Save medicine <span>→</span>';
    }
    saveMedicines();
    render();
    showToast("Medicine deleted.");
  } else if (button.dataset.action === "edit") {
    nameInput.value = medicine.name;
    categoryInput.value = medicine.category;
    quantityInput.value = medicine.quantity;
    expiryInput.value = medicine.expiryDate;
    notesInput.value = medicine.notes || "";
    form.dataset.editId = medicine.id;
    form.querySelector('button[type="submit"]').innerHTML = 'Update medicine <span>→</span>';
    document.getElementById("add-medicine").scrollIntoView({ behavior: "smooth", block: "start" });
    nameInput.focus({ preventScroll: true });
  }
});
searchInput.addEventListener("input", render);
filterSelect.addEventListener("change", render);

// Set the date picker minimum to today; past dates are still shown correctly if already saved.
const today = new Date();
expiryInput.min = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
render();
